package test;

public class GradeAnalyzer {
    public static void main(String[] args) {
       
        int[] grades = {85, 92, 78, 88, 91, 76, 95, 89, 84, 90};

      
        double averageGrade = calculateAverage(grades);

      
        int highestGrade = findHighestGrade(grades);
        int lowestGrade = findLowestGrade(grades);

        
        System.out.println("Average Grade: " + averageGrade);
        System.out.println("Highest Grade: " + highestGrade);
        System.out.println("Lowest Grade: " + lowestGrade);
    }

    public static  int calculateAverage(int[] grades) {
        int sum = 0;
        for (int grade : grades) {
            sum += grade;
        }
        return  sum / grades.length;
    }

    public static int findHighestGrade(int[] grades) {
        int highest = grades[0];
        for (int grade : grades) {
            if (grade > highest) {
                highest = grade;
            }
        }
        return highest;
    }

    public static int findLowestGrade(int[] grades) {
        int lowest = grades[0];
        for (int grade : grades) {
            if (grade < lowest) {
                lowest = grade;
            }
        }
        return lowest;
    }
}